import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Author
from django.db.models import Q, Sum


# Create and run your queries within functions
def get_authors(search_name=None, search_email=None):
    if search_name is None and search_email is None:
        return ''

    query = Q()
    query_name = Q(full_name__icontains=search_name)
    query_email = Q(email__icontains=search_email)

    if search_name is not None and search_email is not None:
        query |= query_name & query_email
    elif search_name is not None:
        query |= query_name
    else:
        query |= query_email

    authors = Author.objects.filter(query).order_by('-full_name')

    if not authors:
        return ''

    return '\n'.join(f"Author: {author.full_name}, email: {author.email},"
                     f" status: {author.is_banned}" for author in authors)


def get_top_publisher():
    publisher = Author.objects.get_authors_by_article_count().first()

    if not publisher:
        return ''

    return f"Top Author: {publisher.full_name} with {publisher.article_count} published articles."


def get_top_reviewer():
    author = Author.objects.prefetch_related('reviews').annotate(
        review_count=Sum('reviews')
    ).order_by('email').first()

    return f"Top Reviewer: {author.full_name} with {author.review_count} published reviews."
